
// Bootstrap tooltips
document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
  new bootstrap.Tooltip(el);
});
// Footer year
const y = document.getElementById('year'); if (y) y.textContent = new Date().getFullYear();
// Progress bars (auto from data-total/data-done)
document.querySelectorAll('[data-progress-bar]').forEach(bar => {
  const total = parseFloat(bar.dataset.total || "0");
  const done  = parseFloat(bar.dataset.done  || "0");
  if(total>0){
    const pct = Math.max(0, Math.min(100, (done/total)*100));
    bar.style.width = pct.toFixed(2) + '%';
    const label = bar.querySelector('[data-progress-percent]');
    if(label){ label.textContent = pct.toLocaleString('ar-SA', { maximumFractionDigits: 1 }) + '%'; }
  }
});
// Prefill WhatsApp message helper
const CONFIG = { whatsapp: { boys: "996050000000", girls: "996050000000" } }; // أضف الأرقام لاحقًا هنا

function waLink(number, payload){
  const digits = (number || "").toString().replace(/[^0-9]/g, ""); // E.164 digits only
  if(!digits) return "";
  const base = `https://api.whatsapp.com/send?phone=${digits}`;
  const text = payload ? `&text=${encodeURIComponent(payload)}` : "";
  return base + text;
}

function openWhatsApp(gender, payload){
  const number = (gender === "بنات") ? CONFIG.whatsapp.girls : CONFIG.whatsapp.boys;
  const url = waLink(number, payload);
  if(!url){
    if (typeof Swal !== "undefined") {
      Swal.fire({icon:'info', title:'لم يتم ضبط رقم واتساب', html:'أضيفي الأرقام داخل <code>nafes.js</code> في <b>CONFIG.whatsapp</b> ثم أعيدي التحميل.'});
    } else {
      alert('لم يتم ضبط رقم واتساب. حدّدي الأرقام في CONFIG.whatsapp داخل nafes.js');
    }
    return;
  }
  window.open(url, '_blank'); // يفتح صفحة api.whatsapp.com مع الرقم
}
    return;
  }
  const base = `https://wa.me/${number}?text=`;
  const msg = encodeURIComponent(payload || "");
  window.open(base + msg, '_blank');
}

// إخفاء أزرار واتساب بالفوتر إن لم تكن الأرقام مضبوطة
document.addEventListener('DOMContentLoaded', ()=>{
  const boys = (CONFIG.whatsapp.boys || "").trim();
  const girls = (CONFIG.whatsapp.girls || "").trim();
  const boysUrl = waLink(boys, "");
  const girlsUrl = waLink(girls, "");

  document.querySelectorAll('[data-wa="boys"]').forEach(btn=>{
    if(boysUrl){
      btn.removeAttribute('disabled'); btn.removeAttribute('title');
      btn.setAttribute('href', boysUrl); btn.setAttribute('target', '_blank'); btn.setAttribute('rel','noopener');
    } else { btn.setAttribute('disabled','disabled'); btn.title='سيضاف لاحقًا'; }
  });
  document.querySelectorAll('[data-wa="girls"]').forEach(btn=>{
    if(girlsUrl){
      btn.removeAttribute('disabled'); btn.removeAttribute('title');
      btn.setAttribute('href', girlsUrl); btn.setAttribute('target', '_blank'); btn.setAttribute('rel','noopener');
    } else { btn.setAttribute('disabled','disabled'); btn.title='سيضاف لاحقًا'; }
  });
});
  }
  if(!girls){
    document.querySelectorAll('[data-wa="girls"]').forEach(btn=>{ btn.setAttribute('disabled','disabled'); btn.title='سيضاف لاحقًا'; });
  }
});?text=`;
  const msg = encodeURIComponent(payload);
  window.open(base + msg, '_blank');
}


// ======== Enhanced Config & Storage ========
if(!window.CONFIG){ window.CONFIG = {}; }
CONFIG.apps_script_url = CONFIG.apps_script_url || ""; // ضع هنا رابط Web App من Google Apps Script (إن وُجد)

const STORAGE_KEY = "nafes_registrations_v1";

function getRegistrations(){
  try{ return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }catch(_){ return []; }
}
function saveRegistrations(list){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}
function addRegistration(entry){
  const list = getRegistrations();
  list.push(entry);
  saveRegistrations(list);
}

// تحويل جوال سعودي (05xxxx) إلى E.164 (9665xxxx)
function normalizeKsaMobile(raw){
  const digits = (raw||"").replace(/\D/g, "");
  if(digits.startsWith("05")) return "966" + digits.slice(1);
  if(digits.startsWith("5"))  return "966" + digits;
  if(digits.startsWith("966")) return digits;
  return digits; // fallback
}

// ======== Export Helpers ========
function exportCSV(filename="nafes-registrations.csv"){
  const list = getRegistrations();
  if(!list.length){ alert("لا توجد تسجيلات بعد."); return; }
  const headers = ["timestamp","name","mobile","email","district","school","stage","grade","gender","notes"];
  const rows = [headers.join(",")];
  list.forEach(r=>{
    const row = [
      r.timestamp||"", r.name||"", r.mobile||"", r.email||"", r.district||"", r.school||"",
      r.stage||"", r.grade||"", r.gender||"", (r.notes||"").replace(/\r?\n/g," ").replace(/,/g,"؛")
    ].map(v => `"${String(v).replace(/"/g,'""')}"`).join(",");
    rows.push(row);
  });
  const blob = new Blob([rows.join("\n")], {type:"text/csv;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

function exportNumbersCSV(filename="nafes-numbers.csv"){
  const list = getRegistrations();
  if(!list.length){ alert("لا توجد تسجيلات بعد."); return; }
  const numbers = list.map(r => normalizeKsaMobile(r.mobile)).filter(Boolean);
  const blob = new Blob([numbers.join("\n")], {type:"text/csv;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// XLSX export using SheetJS (if loaded)
function exportXLSX(filename="nafes-registrations.xlsx"){
  if(typeof XLSX === "undefined"){ exportCSV("nafes-registrations.csv"); return; }
  const list = getRegistrations();
  if(!list.length){ alert("لا توجد تسجيلات بعد."); return; }
  const ws = XLSX.utils.json_to_sheet(list);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Registrations");
  const wbout = XLSX.write(wb, {bookType:"xlsx", type:"array"});
  const blob = new Blob([wbout], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// ======== Coverage Report ========
function computeCoverage(){
  const list = getRegistrations();
  const byDistrict = {}, byStage = {};
  list.forEach(r=>{
    const d = (r.district||"غير محدد").trim();
    const s = (r.stage||"غير محددة").trim();
    byDistrict[d] = (byDistrict[d]||0) + 1;
    byStage[s] = (byStage[s]||0) + 1;
  });
  return { total: list.length, byDistrict, byStage, list };
}

// ======== Welcome Message ========
function buildWelcomeMessage(data){
  const base = window.location.origin + window.location.pathname.replace(/\/[^\/]*$/, "/");
  const link = p => (base + p);
  return `أهلًا ${data.name || "منسق/ة"} 👋
تم استلام طلب تسجيلك في مشروع اختبارات نافس.

روابط أساسية:
• الموارد التدريبية: ${link("resources.html")}
• حلّل تقدّمك: ${link("analytics.html")}
• خطة 30-60-90 يومًا: ${link("plan.html")}
• لوحة الإنجازات: ${link("achievements.html")}

خطوات الأسبوع الأول:
1) تحليل نتائج المدرسة/الصف وتحديد 2-3 معايير ضعيفة.
2) تنفيذ درس مهاري مركّز (15 دقيقة) + ورقة عمل قصيرة.
3) تشكيل مجموعة دعم صغيرة للمتعثرين والمتابعة أسبوعيًا.
4) إشراك الأسرة بنشاط منزلي بسيط (10 دقائق).

نموذج متابعة أسبوعية (اختياري):
— اكتبوا لي "أرغب بالنموذج" لإرساله أو حمّلوه لاحقًا من الموارد.

شاكرين تعاونكم 🌷`;
}

// ======== Google Apps Script Submit (optional) ========
async function submitToGoogleSheet(entry){
  if(!CONFIG.apps_script_url){ return {ok:false, skipped:true}; }
  try{
    const res = await fetch(CONFIG.apps_script_url, {
      method: "POST",
      mode: "no-cors", // GAS Web App may not return CORS headers; we still fire-and-forget
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(entry)
    });
    return {ok:true};
  }catch(e){
    console.warn("GAS submit failed:", e);
    return {ok:false, error: e};
  }
}


// ===== Admin Auth & Live Sheet Loader =====
CONFIG.admin_pass_sha256 = CONFIG.admin_pass_sha256 || ""; // ضع بصمة SHA-256 لكلمة المرور هنا (اختياري)
CONFIG.google_sheet_csv_url = CONFIG.google_sheet_csv_url || ""; // ضع رابط CSV المنشور من Google Sheet (اختياري)

async function sha256Hex(message){
  const enc = new TextEncoder(); const data = enc.encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}
async function checkAdminPassword(pw){
  if(!CONFIG.admin_pass_sha256){ return true; } // بدون كلمة مرور
  const hex = await sha256Hex(pw || "");
  return hex === CONFIG.admin_pass_sha256.toLowerCase();
}
function rememberAdminSession(){
  sessionStorage.setItem("nafes_admin_ok", "1");
}
function hasAdminSession(){
  return sessionStorage.getItem("nafes_admin_ok") === "1" || !CONFIG.admin_pass_sha256;
}

// Compute coverage from a given list
function computeCoverageFrom(list){
  const byDistrict = {}, byStage = {};
  (list||[]).forEach(r=>{
    const d = (r.district||"غير محدد").trim();
    const s = (r.stage||"غير محددة").trim();
    byDistrict[d] = (byDistrict[d]||0) + 1;
    byStage[s] = (byStage[s]||0) + 1;
  });
  return { total: (list||[]).length, byDistrict, byStage, list };
}

// Load from Google Sheet CSV (published link)
async function loadFromGoogleCSV(){
  const url = (CONFIG.google_sheet_csv_url||"").trim();
  if(!url) return null;
  try{
    const res = await fetch(url, {cache: "no-store"});
    const text = await res.text();
    // Parse CSV via SheetJS if available, else naive parser
    if(typeof XLSX !== "undefined"){
      const wb = XLSX.read(text, {type:"string"});
      const ws = wb.Sheets[wb.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(ws, {defval:""});
      // Normalize headers
      const mapRow = (r) => ({
        timestamp: r.timestamp || r.TIMESTAMP || r.Timestamp || "",
        name: r.name || r.NAME || r["الاسم"] || "",
        mobile: r.mobile || r.MOBILE || r["الجوال"] || "",
        email: r.email || r.EMAIL || r["البريد"] || "",
        district: r.district || r["المكتب/القطاع"] || r.DISTRICT || "",
        school: r.school || r["المدرسة"] || r.SCHOOL || "",
        stage: r.stage || r["المرحلة"] || r.STAGE || "",
        grade: r.grade || r["الصف"] || r.GRADE || "",
        gender: r.gender || r["الفئة"] || r.GENDER || "",
        notes: r.notes || r["ملاحظات"] || r.NOTES || "",
      });
      return json.map(mapRow);
    }else{
      // Minimal CSV split (no quotes support)
      const lines = text.trim().split(/\r?\n/);
      const headers = lines.shift().split(",");
      const idx = {}; headers.forEach((h,i)=> idx[h.trim().toLowerCase()] = i);
      const get = (row, key) => row[idx[key]] ?? "";
      return lines.map(line => {
        const cols = line.split(",");
        return {
          timestamp: get(cols,"timestamp"),
          name: get(cols,"name"),
          mobile: get(cols,"mobile"),
          email: get(cols,"email"),
          district: get(cols,"district"),
          school: get(cols,"school"),
          stage: get(cols,"stage"),
          grade: get(cols,"grade"),
          gender: get(cols,"gender"),
          notes: get(cols,"notes"),
        };
      });
    }
  }catch(e){
    console.warn("loadFromGoogleCSV failed", e);
    return null;
  }
}
